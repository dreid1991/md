#ifndef PARMS
#define PARMS
#include <map>
#include "SpeciesDef.h"
namespace PARMS {
	extern std::map<int, SpeciesDef> SPECIESDEFS;
	extern std::map<int, int> foo;

}
#endif

