#include <iostream>
#include <vector>
#include "Vector.h"
#include "Atom.h"
#include "Box.h"
#include <map>
#include "CreateAtoms.h"
#include "SPECIESDEFS.h"
#include "SpeciesDef.h"
#include "PARMS.h"
using namespace std;
//map<int, SpeciesDef> PARMS::SPECIESDEFS;
map<int, int> PARMS::foo = std::map<int, int>();

int main() {
	asserts::assertSpeciesDefs();
	cout << "lol" << endl;
	for (map<int, SpeciesDef>::iterator it = PARMS::SPECIESDEFS.begin(); it != PARMS::SPECIESDEFS.end(); it++) {
		cout << it->first << endl;
		cout << it->second.m << endl;
	}
	CreateAtoms createAtoms = CreateAtoms();
	Vector origin = Vector(0, 0, 0);
	Vector trace = Vector(10, 10, 10);
	Box bounds = Box(origin, trace);
	vector<Atom> atoms = createAtoms.box(bounds, 1, 10);
	for (unsigned int i=0; i<atoms.size(); i++) {
		cout << atoms[i].p.x << endl;
	}
}
