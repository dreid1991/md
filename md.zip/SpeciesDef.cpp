#include "SpeciesDef.h"

SpeciesDef::SpeciesDef(int type_, int m_, int sig_, int eps_) {
	type = type_;
	m = m_;
	sig = sig_;
	eps = eps_;

}
