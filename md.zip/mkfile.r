app: main.cpp Vector.h Atom.h Atom.cpp CreateAtoms.h CreateAtoms.cpp Box.h Box.cpp SpeciesDef.cpp SpeciesDef.h SPECIESDEFS.h 
	g++ -ansi -pedantic-errors -Wall main.cpp Vector.h Atom.h Atom.cpp CreateAtoms.h CreateAtoms.cpp Box.h Box.cpp SpeciesDef.h SpeciesDef.cpp SPECIESDEFS.h

