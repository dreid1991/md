#include <iostream>
#include <vector>
#include "Box.h"
#include "Atom.h"
#include "Vector.h"
#include "PARMS.h"
#include "CreateAtoms.h"
#include "SpeciesDef.h"
using namespace std;
CreateAtoms::CreateAtoms() {

}
vector<Atom> CreateAtoms::box (Box &bounds, int type, int count) {
	cout << "lol" << endl;
	for (map<int, SpeciesDef>::iterator it = PARMS::SPECIESDEFS.begin(); it != PARMS::SPECIESDEFS.end(); it++) {
		cout << it->first << endl;
		cout << it->second.m << endl;
	}
	SpeciesDef foo = PARMS::SPECIESDEFS.find(1)->second;
	cout << foo.m << endl;
	map<int, SpeciesDef>::iterator defIt = PARMS::SPECIESDEFS.find(type);
	vector<Atom> atoms;

	if (defIt == SPECIESDEFS.end()) {
		cout << "BAD SPECIES DEF" << endl;
		return atoms;
	}
	SpeciesDef def = defIt->second;
	for (int i=0; i<count; i++) {
		atoms.push_back(Atom(def));
	}
	return atoms;
}


