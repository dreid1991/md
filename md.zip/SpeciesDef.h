#ifndef SPECIESDEF_H
#define SPECIESDEF_H

class SpeciesDef {
	public:
		SpeciesDef(int type, int m, int sig, int eps);
		int type;
		int m;
		int sig;
		int eps;

};

#endif
