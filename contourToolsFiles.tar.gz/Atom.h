#ifndef ATOM_H
#define ATOM_H

#include "Vector.h"
#include "timestamped_position.h"
#include <string>
#include <iostream>
#include <vector>
#include <complex>
#include <map>
using namespace std;
class Atom {
	public:
		Atom(double x_, double y_, string type_, int id_) : pos(Vector(x_, y_)) {
			//x = x_;
			//y = y_;
			type = type_;
			id = id_;
			r = 0;
			crystalGroup = NULL;
		}
		vector<Atom*> neighbors;
		vector<Vector> neighborOffsets;
		Vector pos;	
		double r;
		double id;
		vector<timestamped_position> posHist;	
		string type;
		map<int, vector<complex<double> > > qms;
		map<int, double> qs;
		vector<Atom *> *crystalGroup;
		Vector vToNeighbor(int i) {
			return Vector(neighbors[i]->pos.x + neighborOffsets[i].x - pos.x, neighbors[i]->pos.y + neighborOffsets[i].y - pos.y);
		}
		void print() {
			cout << "\nPrintingAtom\n";
			cout << "id: ";
			cout << id;
			cout << "\ntype: ";
			cout << type;
			cout << "\nx: ";
			cout << pos.x;
			cout << "\ny: ";
			cout << pos.y;
			cout << "\n";
		}
};

#endif
