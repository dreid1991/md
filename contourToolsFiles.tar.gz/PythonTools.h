#ifndef PYTHONTOOLS_H
#define PYTHONTOOLS_H
#include "Python.h"
#include "Snap.h"
#include "DataTools.h"
#include "math.h"
#include <algorithm>
#include <stdlib.h>
#include <map>
#include <string>
#include <vector>
#include <fstream>
#include <sys/dir.h>
//#include <regex>
#include <dirent.h>
#include <sys/types.h>
#include "fileSpec.h"
using namespace std;
class PythonTools {
	public:
		PyObject *dumpFunc;
		PyObject *plt;
		PyObject *show;
		PyObject *savefig;
		PyObject *scatter;
		PyObject *grabFileNamesF;
		PyObject *plot;
		PyObject *grabDataMod;
		PyObject *hist;
		//Dump grabDump(string fn);
		string vectorToStr(vector<double> *);
		PythonTools(){}
		void setDump(PyObject *);
		void setPlt(PyObject *);
		void setGrab(PyObject *);
		bool allNums(string str);
		int countDataCols(vector<string> *);
		PyObject * doubleVecToPy(vector<double> *);
		void appendSnap(PyObject *pySnps, vector<Snap> *cSnps, int idx);
		vector<Snap> loadDump(string fn, double timestep);
		map<int, string> readDescData(string folderName, string entry);
		map<int, vector<string> > grabFileNames(string folderName, map<int, FileSpec>);
		PyObject *mapIntDoubleToPy(map<int, double> &);
		map<string, vector<double> > grabData(string, long);
		vector<string> PyToVecString(PyObject *);
		vector<double> PyToVecDouble(PyObject *);
		void scatterAtoms(vector<Atom *> &, PyObject *dict);
		vector<string> grabVDepByDesc(vector<string> folders, string descItem, string val);
};
#endif
